package com.example.gallery;
public class University{
	private String name;  // 学校名称

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}