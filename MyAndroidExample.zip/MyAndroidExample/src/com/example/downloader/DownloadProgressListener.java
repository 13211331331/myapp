package com.example.downloader;

public interface DownloadProgressListener {
	public void onDownloadSize(int size);
}
