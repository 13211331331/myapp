package com.example.tabhost;

import android.app.Activity;
import android.os.Bundle;

import com.example.R;

public class NormalActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.normal);
        
    }
}
